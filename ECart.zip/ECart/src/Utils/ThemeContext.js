import { createContext, useState } from "react";

const ThemeContext = createContext()

export const Theme = ({children})=>{
    const [theme,setTheme] = useState("light")
    const toggleTheme = ()=>setTheme((prev)=>prev==="light" ? "dark" : "light")
    return(
        <ThemeContext.Provider value={{theme,toggleTheme}}>
            {children}
        </ThemeContext.Provider>
    )
}
export default ThemeContext